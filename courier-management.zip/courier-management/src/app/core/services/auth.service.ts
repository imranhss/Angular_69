import { Injectable } from '@angular/core';
import { environment } from '../../../environment';
import { BehaviorSubject, map, Observable, tap } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class AuthService {

  private baseUrl = environment.apiUrl;

  private tokenKey = 'auth_token';

  private userKey = 'user';

  // =========================
  // USER STATE
  // =========================

  private currentUserSubject =
    new BehaviorSubject<any>(
      this.getUserFromStorage()
    );

  currentUser$ =
    this.currentUserSubject.asObservable();

  constructor(
    private http: HttpClient
  ) { }

  // =========================
  // LOGIN
  // =========================

login(email: string, password: string): Observable<any> {
    return this.http.get<any[]>(`${this.baseUrl}/users?email=${email}`)
      .pipe(
        map(users => {
          if (!users || users.length === 0) {
            return null;
          }

          const user = users[0];

          if (user.password === password) {
            // store session
            localStorage.setItem('user', JSON.stringify(user));
            return user;
          }

          return null;
        })
      );
  }

  // =========================
  // REGISTER
  // =========================

  register(data: any): Observable<any> {

    const newUser = {

      ...data,

      role: 'customer',

      status: 'active',

      createdAt: new Date().toISOString(),

      avatar: this.generateAvatar(data.name)
    };

    return this.http.post(
      `${this.baseUrl}/users`,
      newUser
    );
  }

  // =========================
  // LOGOUT
  // =========================

  logout(): void {

    localStorage.removeItem(this.tokenKey);

    localStorage.removeItem(this.userKey);

    this.currentUserSubject.next(null);
  }

  // =========================
  // TOKEN METHODS
  // =========================

  setToken(token: string): void {

    localStorage.setItem(
      this.tokenKey,
      token
    );
  }

  getToken(): string | null {

    return localStorage.getItem(
      this.tokenKey
    );
  }

  isLoggedIn(): boolean {

    return !!this.getToken();
  }

  // =========================
  // USER METHODS
  // =========================

  setUser(user: any): void {

    localStorage.setItem(
      this.userKey,
      JSON.stringify(user)
    );
  }

  getUser(): any {

    return JSON.parse(
      localStorage.getItem(this.userKey) || 'null'
    );
  }

  private getUserFromStorage(): any {

    return this.getUser();
  }

  // =========================
  // ROLE CHECK
  // =========================

  hasRole(role: string): boolean {

    const user = this.getUser();

    return user?.role === role;
  }

  isCustomer(): boolean {

    return this.hasRole('customer');
  }

  isAdmin(): boolean {

    return this.hasRole('admin');
  }

  isRider(): boolean {

    return this.hasRole('rider');
  }

  // =========================
  // AVATAR GENERATOR
  // =========================

  private generateAvatar(
    name: string
  ): string {

    const parts = name.split(' ');

    if (parts.length === 1) {
      return parts[0][0].toUpperCase();
    }

    return (
      parts[0][0] +
      parts[1][0]
    ).toUpperCase();
  }

}
