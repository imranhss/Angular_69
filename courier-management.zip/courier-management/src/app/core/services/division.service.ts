import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Division } from '../models/location.model';
import { Observable } from 'rxjs';
import { environment } from '../../../environment';

@Injectable({
  providedIn: 'root',
})
export class DivisionService {

  private divisionApi = environment.apiUrl + '/divisions';

  constructor(private http: HttpClient) { }

  // =========================
  // Division CRUD
  // =========================

  // Get All Divisions
  getDivisions(): Observable<Division[]> {
    return this.http.get<Division[]>(this.divisionApi);
  }

  // Get Division By ID
  getDivisionById(id: string): Observable<Division> {
    return this.http.get<Division>(
      `${this.divisionApi}/${id}`
    );
  }

  // Add Division
  addDivision(
    division: Division
  ): Observable<Division> {
    return this.http.post<Division>(
      this.divisionApi,
      division
    );
  }

  // Update Division
  updateDivision(
    id: string,
    division: Division
  ): Observable<Division> {
    return this.http.put<Division>(
      `${this.divisionApi}/${id}`,
      division
    );
  }

  // Delete Division
  deleteDivision(id: string): Observable<void> {
    return this.http.delete<void>(
      `${this.divisionApi}/${id}`
    );
  }

  
}
