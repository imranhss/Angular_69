import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Country } from '../models/location.model';
import { Observable } from 'rxjs';
import { environment } from '../../../environment';

@Injectable({
  providedIn: 'root',
})
export class CountryService {


  private apiUrl = environment.apiUrl+'/countries';

  constructor(private http: HttpClient) {}

  // Get All
  getCountries(): Observable<Country[]> {
    return this.http.get<Country[]>(
      this.apiUrl
    );
  }

  // Add
  addCountry(
    country: Country
  ): Observable<Country> {
    return this.http.post<Country>(
      this.apiUrl,
      country
    );
  }

  // Update
  updateCountry(
    id: string,
    country: Country
  ): Observable<Country> {
    return this.http.put<Country>(
      `${this.apiUrl}/${id}`,
      country
    );
  }

  // Delete
  deleteCountry(
    id: string
  ): Observable<void> {
    return this.http.delete<void>(
      `${this.apiUrl}/${id}`
    );
  }
  
}
