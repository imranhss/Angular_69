import { Injectable } from '@angular/core';
import { environment } from '../../../environment';
import { HttpClient } from '@angular/common/http';
import { District } from '../models/location.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class DistrictService {

  private apiUrl = environment.apiUrl + '/districts';


  constructor(private http: HttpClient) { }

  // Get All Districts
  getDistricts(): Observable<District[]> {
    return this.http.get<District[]>(this.apiUrl);
  }

  // Get District By ID
  getDistrictById(id: string): Observable<District> {
    return this.http.get<District>(`${this.apiUrl}/${id}`);
  }

  // Add District
  addDistrict(district: District): Observable<District> {
    return this.http.post<District>(this.apiUrl, district);
  }

  // Update District
  updateDistrict(
    id: string,
    district: District
  ): Observable<District> {
    return this.http.put<District>(
      `${this.apiUrl}/${id}`,
      district
    );
  }

  // Delete District
  deleteDistrict(id: string): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }

}
