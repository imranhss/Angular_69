import { Injectable } from '@angular/core';
import { environment } from '../../../environment';
import { Observable } from 'rxjs';
import { PoliceStation } from '../models/location.model';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class PolicetstaionService {


  constructor(
    private http: HttpClient
  ) { }

  private baseUrl = environment.apiUrl + '/policestations';


  save(police: PoliceStation): Observable<PoliceStation> {
    return this.http.post<PoliceStation>(this.baseUrl, police);
  }

  getAll(): Observable<PoliceStation[]> {
    return this.http.get<PoliceStation[]>(this.baseUrl);
  }

  getById(id: string): Observable<PoliceStation> {
    return this.http.get<PoliceStation>(this.baseUrl + '/' + id);
  }

  delete(id: string): Observable<void> {
    return this.http.delete<void>(this.baseUrl + '/' + id);
  }

  update(id: string, police: PoliceStation): Observable<PoliceStation> {
    return this.http.put<PoliceStation>(this.baseUrl + '/' + id, police);
  }



}
