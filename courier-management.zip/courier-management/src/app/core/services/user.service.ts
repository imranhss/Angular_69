import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environment';
import { User } from '../models/user.model';

@Injectable({
  providedIn: 'root',
})
export class UserService {

  private baseUrl = environment.apiUrl+'/users';

  constructor(private http: HttpClient) { }

  // GET CURRENT USER
  getCurrentUser(): User {
    return JSON.parse(localStorage.getItem('user') || 'null');
  }

  // GET ALL USERS (Admin dashboard)
  getAllUsers(): Observable<User[]> {
    return this.http.get<User[]>(`${this.baseUrl}`);
  }

  // GET USER BY ID
  getUserById(id: number): Observable<User> {
    return this.http.get<User>(`${this.baseUrl}/users/${id}`);
  }

  // UPDATE USER PROFILE
  updateUser(id: number, data: Partial<User>): Observable<User> {
    return this.http.put<User>(`${this.baseUrl}/users/${id}`, data);
  }


   // Delete User
  deleteUser(
    id: number
  ): Observable<void> {
    return this.http.delete<void>(
      `${this.baseUrl}/${id}`
    );
  }



    // Add User
  addUser(user: User): Observable<User> {
    return this.http.post<User>(
      this.baseUrl,
      user
    );
  }
}