export interface OTPStore {
  id?: number;

  phone: string;

  otp: string;

  createdAt: string;
}