export type ParcelStatus =
  | 'pending'
  | 'picked-up'
  | 'in-transit'
  | 'out-for-delivery'
  | 'delivered'
  | 'cancelled'
  | 'returned';

export type ServiceType =
  | 'standard'
  | 'express'
  | 'overnight'
  | 'same-day';

export type ParcelType =
  | 'document'
  | 'product'
  | 'fragile'
  | 'heavy'
  | 'perishable';

export type PaymentMethod =
  | 'cod'
  | 'prepaid'
  | 'bkash'
  | 'nagad'
  | 'sslcommerz';

export type PaymentStatus =
  | 'pending'
  | 'paid'
  | 'failed'
  | 'refunded';

export type PriorityType =
  | 'normal'
  | 'high'
  | 'urgent';

export interface ParcelHistory {
  date: string;

  status: ParcelStatus;

  note: string;

  location: string;
}

export interface Parcel {
  id?: number;

  trackingCode: string;

  customerId: number;

  riderId: number | null;

  senderName: string;

  senderPhone: string;

  senderAddress: string;

  receiverName: string;

  receiverPhone: string;

  receiverAddress: string;

  parcelType: ParcelType;

  weight: number;

  description: string;

  serviceType: ServiceType;

  deliveryCharge: number;

  codAmount: number;

  paymentMethod: PaymentMethod;

  paymentStatus: PaymentStatus;

  status: ParcelStatus;

  priority: PriorityType;

  estimatedDelivery: string;

  createdAt: string;

  updatedAt: string;

  history: ParcelHistory[];
}