export type EarningStatus =
  | 'credited'
  | 'pending';

export interface Earning {
  id?: number;

  riderId: number;

  parcelId: number;

  amount: number;

  date: string;

  status: EarningStatus;
}