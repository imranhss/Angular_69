export interface KPIAnalytics {
  totalDeliveries: number;

  deliveredCount: number;

  failedCount: number;

  inTransitCount: number;

  totalRevenue: number;

  pendingRevenue: number;

  activeRiders: number;
}

export interface RevenueByMonth {
  month: string;

  revenue: number;
}

export interface DeliveryStatusAnalytics {
  status: string;

  total: number;
}

export interface TopRider {
  riderId: number;

  riderName: string;

  totalDeliveries: number;

  earnings: number;

  rating: number;
}

export interface RevenueByGateway {
  gateway: string;

  total: number;
}