// country.ts
export interface Country {
  id: string;
  name: string;
  divisions: string[];
}


// division.ts
export interface Division {
  id: string;
  name: string;
  districts: string[];
}


// district.ts
export interface District {
  id: string;
  name: string;
  policeStations: string[];
}

// police-station.ts
export interface PoliceStation {
  id?: string;
  name: string;
}



