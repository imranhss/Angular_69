export type NotificationType =
  | 'success'
  | 'info'
  | 'warning'
  | 'error';

export interface Notification {
  id?: number;

  userId: number;

  title: string;

  message: string;

  type: NotificationType;

  read: boolean;

  createdAt: string;
}