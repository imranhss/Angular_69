export interface Zone {
  id?: number;

  name: string;

  areas: string[];
}