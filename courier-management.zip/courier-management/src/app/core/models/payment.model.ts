export type PaymentGateway =
  | 'bkash'
  | 'nagad'
  | 'sslcommerz'
  | 'cod';

export type PaymentTransactionStatus =
  | 'success'
  | 'pending'
  | 'failed';

export interface Payment {
  id?: number;

  parcelId: number;

  customerId: number;

  amount: number;

  method: string;

  gateway: PaymentGateway;

  transactionId: string;

  status: PaymentTransactionStatus;

  createdAt: string;
}