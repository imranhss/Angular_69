import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { AuthService } from '../../core/services/auth.service';
import { Router } from '@angular/router';
import { User } from '../../core/models/user.model';
import { UserService } from '../../core/services/user.service';

@Component({
  selector: 'app-sidebar',
  imports: [],
  templateUrl: './sidebar.html',
  styleUrl: './sidebar.css',
})
export class Sidebar implements OnInit{


   user!: User;

  constructor(
    private authService: AuthService,
    private router: Router,
    private userService: UserService, private cdr: ChangeDetectorRef
  ) {}

 ngOnInit(): void {
    this.loadCurrentUser();
    
  }


  logout() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }


  // current logged user
  loadCurrentUser() {
    this.user = this.userService.getCurrentUser();
    this.cdr.markForCheck();
    console.log(this.user+"55555555555555555");
  }

}
