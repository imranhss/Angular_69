import { Component } from '@angular/core';

@Component({
  selector: 'app-rider-dashboardcomponent',
  imports: [],
  templateUrl: './rider-dashboardcomponent.html',
  styleUrl: './rider-dashboardcomponent.css',
})
export class RiderDashboardcomponent {

}
