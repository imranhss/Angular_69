import { ChangeDetectorRef, Component } from '@angular/core';
import { CountryService } from '../../../core/services/country.service';
import { DivisionService } from '../../../core/services/division.service';
import { Country, Division } from '../../../core/models/location.model';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-countrycomponent',
  imports: [CommonModule, FormsModule],
  templateUrl: './countrycomponent.html',
  styleUrl: './countrycomponent.css',
})
export class Countrycomponent {

  countries: Country[] = [];
  filteredCountries: Country[] = [];

  divisions: Division[] = [];

  country: Country = {
    id: '',
    name: '',
    divisions: [],
  };

  searchText = '';
  isEdit = false;

  constructor(
    private countryService: CountryService,
    private divisionService: DivisionService,
    private cdr : ChangeDetectorRef

  ) {}

  ngOnInit(): void {
    this.loadCountries();
    this.loadDivisions();
  }

  // =========================
  // Load Countries
  // =========================
  loadCountries() {
    this.countryService
      .getCountries()
      .subscribe((res) => {
        this.countries = res;
        this.filteredCountries = res;
      });
  }

  // =========================
  // Load Divisions
  // =========================
  loadDivisions() {
    this.divisionService
      .getDivisions()
      .subscribe((res) => {
        this.divisions = res;
      });
  }

  // =========================
  // Checkbox Change
  // =========================
  onDivisionChange(
    event: any,
    divisionId: string
  ) {
    if (event.target.checked) {
      this.country.divisions.push(
        divisionId
      );
    } else {
      this.country.divisions =
        this.country.divisions.filter(
          (id) => id !== divisionId
        );
    }
  }

  // =========================
  // Save Country
  // =========================
  saveCountry() {
    if (!this.country.name) {
      alert('Country name required');
      return;
    }

    if (this.isEdit) {
      this.countryService
        .updateCountry(
          this.country.id,
          this.country
        )
        .subscribe(() => {
          this.loadCountries();
          this.resetForm();
        });
    } else {
      this.country.id =
        Date.now().toString();

      this.countryService
        .addCountry(this.country)
        .subscribe(() => {
          this.loadCountries();
          this.resetForm();
        });
    }
  }

  // =========================
  // Edit
  // =========================
  editCountry(country: Country) {
    this.isEdit = true;

    this.country = {
      id: country.id,
      name: country.name,
      divisions: [...country.divisions],
    };
  }

  // =========================
  // Delete
  // =========================
  deleteCountry(id: string) {
    if (confirm('Delete this country?')) {
      this.countryService
        .deleteCountry(id)
        .subscribe(() => {
          this.loadCountries();
        });
    }
  }

  // =========================
  // Search
  // =========================
  searchCountry() {
    const text =
      this.searchText.toLowerCase();

    this.filteredCountries =
      this.countries.filter((country) =>
        country.name
          .toLowerCase()
          .includes(text)
      );
  }

  // =========================
  // Reset
  // =========================
  resetForm() {
    this.isEdit = false;

    this.country = {
      id: '',
      name: '',
      divisions: [],
    };
  }

  // =========================
  // Get Division Names
  // =========================
  getDivisionNames(
    ids: string[]
  ): string {
    return this.divisions
      .filter((division) =>
        ids.includes(division.id)
      )
      .map((division) => division.name)
      .join(', ');
  }

  // =========================
  // Checked
  // =========================
  isChecked(id: string): boolean {
    return this.country.divisions.includes(
      id
    );
  }

}
