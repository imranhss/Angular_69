import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { District, PoliceStation } from '../../../core/models/location.model';
import { DistrictService } from '../../../core/services/district.service';
import { PolicetstaionService } from '../../../core/services/policetstaion.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-districtcomponent',
  imports: [CommonModule, FormsModule],
  templateUrl: './districtcomponent.html',
  styleUrl: './districtcomponent.css',
})
export class Districtcomponent implements OnInit {

  districts: District[] = [];
  filteredDistricts: District[] = [];

  policeStations: PoliceStation[] = [];

  district: District = {
    id: '',
    name: '',
    policeStations: [],
  };

  searchText = '';
  isEdit = false;

  constructor(private districtService: DistrictService,
    private policeService: PolicetstaionService,
    private cdr: ChangeDetectorRef

  ) { }
  ngOnInit(): void {

    this.loadDistricts();
    this.loadPoliceStations();
  }




  // Load Police Stations
  loadPoliceStations() {
    this.policeService
      .getAll()
      .subscribe((res) => {
        this.policeStations = res;
        this.cdr.markForCheck();
      });
  }

  // Load Districts
  loadDistricts() {
    this.districtService.getDistricts().subscribe((res) => {
      this.districts = res;
      this.filteredDistricts = res;
      this.cdr.markForCheck();
    });
  }


  // Checkbox Select
  onCheckboxChange(event: any, id: string) {
    if (event.target.checked) {
      this.district.policeStations.push(id);
    } else {
      this.district.policeStations =
        this.district.policeStations.filter(
          (x) => x !== id
        );
    }
  }


   // Save
  saveDistrict() {
    if (!this.district.name) {
      alert('District name required');
      return;
    }

    if (this.isEdit && this.district.id) {
      this.districtService
        .updateDistrict(this.district.id, this.district)
        .subscribe(() => {
          this.loadDistricts();
          this.resetForm();
        });
    } else {
      this.districtService
        .addDistrict(this.district)
        .subscribe(() => {
          this.loadDistricts();
          this.resetForm();
        });
    }
  }

  // Edit
  editDistrict(district: District) {
    this.isEdit = true;

    this.district = {
      id: district.id,
      name: district.name,
      policeStations: [...district.policeStations],
    };
  }

  // Delete
  deleteDistrict(id: string) {
    if (confirm('Delete this district?')) {
      this.districtService
        .deleteDistrict(id)
        .subscribe(() => {
          this.loadDistricts();
        });
    }
  }

  // Search
  searchDistrict() {
    const text = this.searchText.toLowerCase();

    this.filteredDistricts = this.districts.filter(
      (district) =>
        district.name.toLowerCase().includes(text)
    );
  }

  // Reset
  resetForm() {
    this.isEdit = false;

    this.district = {
      id:'',
      name: '',
      policeStations: [],
    };
  }

  // Get Police Station Names
  getPoliceStationNames(ids: string[]): string {
    return this.policeStations
      .filter((ps) => ids.includes(ps.id!))
      .map((ps) => ps.name)
      .join(', ');
  }

  // Check Selected
  isChecked(id: string): boolean {
    return this.district.policeStations.includes(id);
  }




}
