import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { District, Division } from '../../../core/models/location.model';
import { DivisionService } from '../../../core/services/division.service';
import { DistrictService } from '../../../core/services/district.service';

@Component({
  selector: 'app-divisioncomponet',
  imports: [CommonModule, FormsModule],
  templateUrl: './divisioncomponet.html',
  styleUrl: './divisioncomponet.css',
})
export class Divisioncomponet implements OnInit{

divisions: Division[] = [];
  filteredDivisions: Division[] = [];

  districts: District[] = [];

  division: Division = {
    id: '',
    name: '',
    districts: [],
  };

  searchText = '';
  isEdit = false;

  constructor(
    private divisionService: DivisionService,
    private districtService: DistrictService,
    private cdr : ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.loadDivisions();
    this.loadDistricts();
  }



    // =========================
  // Load Divisions
  // =========================
  loadDivisions() {
    this.divisionService
      .getDivisions()
      .subscribe((res) => {
        this.divisions = res;
        this.filteredDivisions = res;
        this.cdr.markForCheck();
      });
  }

  // =========================
  // Load Districts
  // =========================
  loadDistricts() {
    this.districtService
      .getDistricts()
      .subscribe((res) => {
        this.districts = res;
        this.cdr.markForCheck();
      });
  }

  // =========================
  // Checkbox Change
  // =========================
  onDistrictChange(
    event: any,
    districtId: string
  ) {
    if (event.target.checked) {
      this.division.districts.push(districtId);
    } else {
      this.division.districts =
        this.division.districts.filter(
          (id) => id !== districtId
        );
    }
  }

  // =========================
  // Save Division
  // =========================
  saveDivision() {
    if (!this.division.name) {
      alert('Division name required');
      return;
    }

    if (this.isEdit) {
      this.divisionService
        .updateDivision(
          this.division.id,
          this.division
        )
        .subscribe(() => {
          this.loadDivisions();
          this.resetForm();
        });
    } else {
      this.division.id = Date.now().toString();

      this.divisionService
        .addDivision(this.division)
        .subscribe(() => {
          this.loadDivisions();
          this.resetForm();
        });
    }
  }

  // =========================
  // Edit
  // =========================
  editDivision(division: Division) {
    this.isEdit = true;

    this.division = {
      id: division.id,
      name: division.name,
      districts: [...division.districts],
    };
  }

  // =========================
  // Delete
  // =========================
  deleteDivision(id: string) {
    if (confirm('Delete this division?')) {
      this.divisionService
        .deleteDivision(id)
        .subscribe(() => {
          this.loadDivisions();
        });
    }
  }

  // =========================
  // Search
  // =========================
  searchDivision() {
    const text = this.searchText.toLowerCase();

    this.filteredDivisions =
      this.divisions.filter((division) =>
        division.name
          .toLowerCase()
          .includes(text)
      );
  }

  // =========================
  // Reset
  // =========================
  resetForm() {
    this.isEdit = false;

    this.division = {
      id: '',
      name: '',
      districts: [],
    };
  }

  // =========================
  // Get District Names
  // =========================
  getDistrictNames(ids: string[]): string {
    return this.districts
      .filter((district) =>
        ids.includes(district.id)
      )
      .map((district) => district.name)
      .join(', ');
  }

  // =========================
  // Check Selected
  // =========================
  isChecked(id: string): boolean {
    return this.division.districts.includes(id);
  }




}
