import { ChangeDetectorRef, Component } from '@angular/core';
import { PoliceStation } from '../../../core/models/location.model';
import { PolicetstaionService } from '../../../core/services/policetstaion.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-policesation-componet',
  imports: [CommonModule, FormsModule],
  templateUrl: './policesation-componet.html',
  styleUrl: './policesation-componet.css',
})
export class PolicesationComponet {

  policeStations: PoliceStation[] = [];

  isEdit: boolean = false;

  police: PoliceStation = {
    id: '',
    name: '',
  };

  constructor(
    private policeService: PolicetstaionService,
    private cdr: ChangeDetectorRef
  ) { }

  // ===============================
  // GET ALL
  // ===============================
  loadPoliceStations() {

    this.policeService.getAll().subscribe({
      next: (res) => {
        this.policeStations = res;
        console.log(res);
        this.cdr.markForCheck();
      },
      error: (err) => {
        console.log(err);
      },
    });
  }

  // ===============================
  // SAVE
  // ===============================
  savePolice() {

    if (!this.police.name) {
      alert('Police Station Name Required');
      return;
    }

    this.policeService.save(this.police).subscribe({
      next: () => {
        alert('Saved Successfully');
        this.resetForm();
        this.loadPoliceStations();
      },
      error: (err) => {
        console.log(err);
      },
    });
  }
  // ===============================
  // EDIT
  // ===============================
  editPolice(police: PoliceStation): void {
    this.isEdit = true;

    this.police = {
      id: police.id,
      name: police.name,
    };
  }

  // ===============================
  // UPDATE
  // ===============================
  updatePolice() {

    if (!this.police.id) return;

    this.policeService
      .update(this.police.id, this.police)
      .subscribe({
        next: () => {
          alert('Updated Successfully');
          this.resetForm();
          this.loadPoliceStations();
        },
        error: (err) => {
          console.log(err);
        },
      });
  }


  // ===============================
  // DELETE
  // ===============================
  deletePolice(id: string): void {

    if (confirm('Are you sure to delete?')) {

      this.policeService.delete(id).subscribe({
        next: () => {
          alert('Deleted Successfully');
          this.loadPoliceStations();
        },
        error: (err) => {
          console.log(err);
        },
      });

    }
  }

  resetForm(): void {

    this.police = {
      id: '',
      name: '',
    };

    this.isEdit = false;
  }


}
