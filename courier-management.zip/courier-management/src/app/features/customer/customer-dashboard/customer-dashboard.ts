import { ChangeDetectorRef, Component } from '@angular/core';
import { User } from '../../../core/models/user.model';
import { UserService } from '../../../core/services/user.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-customer-dashboard',
  imports: [CommonModule],
  templateUrl: './customer-dashboard.html',
  styleUrl: './customer-dashboard.css',
})
export class CustomerDashboard {



  user!: User;
  users: User[] = [];

  constructor(private userService: UserService, private cdr: ChangeDetectorRef) { }

  ngOnInit(): void {
    this.loadCurrentUser();
    this.loadUsers();
  }

  // current logged user
  loadCurrentUser() {
    this.user = this.userService.getCurrentUser();
    this.cdr.markForCheck();
    console.log(this.user);
  }

  // admin list
  loadUsers() {
    this.userService.getAllUsers().subscribe({


      next: (res) => {
        this.users = res;
        this.cdr.markForCheck();
        console.log(res)
      }


      ,
      error: (err) => console.log(err)

    });
  }
}
