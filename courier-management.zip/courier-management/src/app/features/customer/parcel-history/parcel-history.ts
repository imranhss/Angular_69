import { Component } from '@angular/core';

@Component({
  selector: 'app-parcel-history',
  imports: [],
  templateUrl: './parcel-history.html',
  styleUrl: './parcel-history.css',
})
export class ParcelHistory {

}
