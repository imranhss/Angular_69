import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { User } from '../../../core/models/user.model';
import { Country, District, Division, PoliceStation } from '../../../core/models/location.model';
import { UserService } from '../../../core/services/user.service';
import { CountryService } from '../../../core/services/country.service';
import { DivisionService } from '../../../core/services/division.service';
import { DistrictService } from '../../../core/services/district.service';
import { PolicetstaionService } from '../../../core/services/policetstaion.service';
import { Observable } from 'rxjs';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-add-customer-component',
  imports: [CommonModule, FormsModule ],
  templateUrl: './add-customer-component.html',
  styleUrl: './add-customer-component.css',
})
export class AddCustomerComponent implements OnInit {


  users: User[] = [];
  filteredUsers: User[] = [];

  countries: Country[] = [];
  divisions: Division[] = [];
  districts: District[] = [];
  policeStations: PoliceStation[] = [];

  filteredDivisions: Division[] = [];
  filteredDistricts: District[] = [];
  filteredPoliceStations: PoliceStation[] = [];

  selectedCountry = '';
  selectedDivision = '';
  selectedDistrict = '';
  selectedPoliceStation = '';

  searchText = '';

  isEdit = false;

  user: User = {
    name: '',
    email: '',
    password: '',
    role: 'CUSTOMER',
    phone: '',
    status: 'active',
    avatar: '',
    address: '',
    createdAt: new Date().toISOString(),
  };

  constructor(
    private userService: UserService,
    private countryService: CountryService,
    private divisionService: DivisionService,
    private districtService: DistrictService,
    private policeStationService: PolicetstaionService,
    private cdr: ChangeDetectorRef


  ) { }


  ngOnInit(): void {
    this.loadUsers();
    this.loadCountries();
    this.loadDivisions();
    this.loadDistricts();
    this.loadPoliceStations();
  }

  loadCountries() {
    this.countryService
      .getCountries()
      .subscribe((res) => {
        this.countries = res;
        this.cdr.markForCheck();
      });
  }

  loadUsers() {
    this.userService.getAllUsers().subscribe((res) => {
      this.users = res;
      this.filteredUsers = res;
      this.cdr.markForCheck();
    });
  }

  loadDivisions() {
    this.divisionService
      .getDivisions()
      .subscribe((res) => {
        this.divisions = res;
        this.cdr.markForCheck();
      });
  }

  loadDistricts() {
    this.districtService
      .getDistricts()
      .subscribe((res) => {
        this.districts = res;
        this.cdr.markForCheck();
      });
  }

  loadPoliceStations() {
    this.policeStationService
      .getAll()
      .subscribe((res) => {
        this.policeStations = res;
         this.cdr.markForCheck();
      });
  }


  // =========================
  // COUNTRY CHANGE
  // =========================

  onCountryChange() {
    this.selectedDivision = '';
    this.selectedDistrict = '';
    this.selectedPoliceStation = '';

    this.filteredDistricts = [];
    this.filteredPoliceStations = [];

    const country = this.countries.find(
      (x) => x.id === this.selectedCountry
    );

    if (country) {
      this.filteredDivisions =
        this.divisions.filter((division) =>
          country.divisions.includes(
            division.id
          )
        );
    }
  }

  // =========================
  // DIVISION CHANGE
  // =========================

  onDivisionChange() {
    this.selectedDistrict = '';
    this.selectedPoliceStation = '';

    this.filteredPoliceStations = [];

    const division = this.divisions.find(
      (x) => x.id === this.selectedDivision
    );

    if (division) {
      this.filteredDistricts =
        this.districts.filter((district) =>
          division.districts.includes(
            district.id
          )
        );
    }
  }

  // =========================
  // DISTRICT CHANGE
  // =========================

  onDistrictChange() {
    this.selectedPoliceStation = '';

    const district = this.districts.find(
      (x) => x.id === this.selectedDistrict
    );

    if (district) {
      this.filteredPoliceStations =
        this.policeStations.filter((ps) =>
          district.policeStations.includes(
            ps.id!
          )
        );
    }
  }

   // =========================
  // SAVE CUSTOMER
  // =========================

  saveUser() {
    this.user.role = 'CUSTOMER';

    this.user.zone =
      this.selectedPoliceStation;

    if (this.isEdit) {
      this.userService
        .updateUser(
          this.user.id!,
          this.user
        )
        .subscribe(() => {
          this.loadUsers();
          this.resetForm();
        });
    } else {
      this.user.createdAt =
        new Date().toISOString();

      this.userService
        .addUser(this.user)
        .subscribe(() => {
          this.loadUsers();
          this.resetForm();
        });
    }
  }

  // =========================
  // EDIT
  // =========================

  editUser(user: User) {
    this.isEdit = true;

    this.user = { ...user };
  }

  // =========================
  // DELETE
  // =========================

  deleteUser(id: number) {
    if (confirm('Delete customer?')) {
      this.userService
        .deleteUser(id)
        .subscribe(() => {
          this.loadUsers();
        });
    }
  }

  // =========================
  // SEARCH
  // =========================

  searchUser() {
    const text =
      this.searchText.toLowerCase();

    this.filteredUsers =
      this.users.filter(
        (user) =>
          user.name
            .toLowerCase()
            .includes(text) ||
          user.phone
            .toLowerCase()
            .includes(text) ||
          user.email
            .toLowerCase()
            .includes(text)
      );
  }

  // =========================
  // RESET
  // =========================

  resetForm() {
    this.isEdit = false;

    this.selectedCountry = '';
    this.selectedDivision = '';
    this.selectedDistrict = '';
    this.selectedPoliceStation = '';

    this.filteredDivisions = [];
    this.filteredDistricts = [];
    this.filteredPoliceStations = [];

    this.user = {
      name: '',
      email: '',
      password: '',
      role: 'CUSTOMER',
      phone: '',
      status: 'active',
      avatar: '',
      address: '',
      createdAt: new Date().toISOString(),
    };
  }

  // =========================
  // GET LOCATION NAME
  // =========================

  getPoliceStationName(id: string) {
    return (
      this.policeStations.find(
        (x) => x.id === id
      )?.name || ''
    );
  }






}
