import { Component } from '@angular/core';
import { AuthService } from '../../../core/services/auth.service';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-login',
  imports: [CommonModule, FormsModule],
  templateUrl: './login.html',
  styleUrl: './login.css',
})
export class Login {



  email: string = '';

  password: string = '';

  loading: boolean = false;

  errorMessage: string = '';

  constructor(
    private authService: AuthService,
    private router: Router
  ) { }

  login() {
    this.authService.login(this.email, this.password)
      .subscribe(user => {
        if (user) {
          console.log('Login success:', user);

          if (user.role === 'ADMIN') {
            this.router.navigate(['/admin-dashboard']);
          } else if (user.role === 'RIDER') {
            this.router.navigate(['/rider-dashboard']);
          } else if (user.role === 'CUSTOMER') {
            this.router.navigate(['/customer-dashboard']);
          }

        } else {
          alert('Invalid email or password');
        }
      });
  }



}
