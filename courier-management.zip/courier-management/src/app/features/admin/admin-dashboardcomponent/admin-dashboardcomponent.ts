import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-dashboardcomponent',
  imports: [],
  templateUrl: './admin-dashboardcomponent.html',
  styleUrl: './admin-dashboardcomponent.css',
})
export class AdminDashboardcomponent {

}
