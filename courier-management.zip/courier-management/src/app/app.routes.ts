import { Routes } from '@angular/router';
import { Login } from './features/auth/login/login';
import { CustomerDashboard } from './features/customer/customer-dashboard/customer-dashboard';
import { RegisterComponent } from './features/auth/register-component/register-component';
import { AdminDashboardcomponent } from './features/admin/admin-dashboardcomponent/admin-dashboardcomponent';
import { RiderDashboardcomponent } from './features/rider/rider-dashboardcomponent/rider-dashboardcomponent';
import { Home } from './shared/home/home';
import { PolicesationComponet } from './features/location/policesation-componet/policesation-componet';
import { Districtcomponent } from './features/location/districtcomponent/districtcomponent';
import { Divisioncomponet } from './features/location/divisioncomponet/divisioncomponet';
import { Countrycomponent } from './features/location/countrycomponent/countrycomponent';
import { AddCustomerComponent } from './features/customer/add-customer-component/add-customer-component';
import { AddCustomerPublicComponent } from './features/customer/add-customer-public-component/add-customer-public-component';

export const routes: Routes = [

    { path: '', component: Home , data:{layout: 'auth' }},



    {
        path: 'login',
        component: Login,
        data: { layout: 'auth' }
    },
    {
        path: 'register',
        component: RegisterComponent,
        data: { layout: 'auth' }
    },
    {
        path: 'admin-dashboard',
        component: AdminDashboardcomponent,
        data: { layout: 'main' }
    },
    {
        path: 'customer-dashboard',
        component: CustomerDashboard,
        data: { layout: 'main' }
    },
    {
        path: 'rider-dashboard',
        component: RiderDashboardcomponent,
        data: { layout: 'main' }
    },
    {
        path: 'police',
        component: PolicesationComponet,
        data: { layout: 'main' }
    },
    {
        path: 'district',
        component: Districtcomponent,
        data: { layout: 'main' }
    },
    {
        path: 'division',
        component: Divisioncomponet,
        data: { layout: 'main' }
    },
    {
        path: 'country',
        component: Countrycomponent,
        data: { layout: 'main' }
    },
    {
        path: 'add-Customer',
        component: AddCustomerComponent,
        data: { layout: 'main' }
    },
    {
        path: 'add-Customer-p',
        component: AddCustomerPublicComponent,
        data: { layout: 'auth' }
    }

];
